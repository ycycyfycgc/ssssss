from pyrogram import Client , Message , Filters
from db import r
import time

helptext = """
__Help:__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Mm] [media] (mute)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Aa]ddf [Word]__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Dd]elf [Word]__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Ll]istf__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Cc]learf__
≼┈┅┅━━━♡━━━┅┅┈≽
__[SS]ik (remove)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Pp]in__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Pp]y (run python3 Scripts)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Del] (delete)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Pp] [money] (price)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Ii]d__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Ss]erver (Srver information)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Aa]ction__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Aa]ction [all|users|off|clear|list]__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Ss]ettings__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Ss]etaction ([Aa]ctionlist)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Ss]pamf [reply] (Word)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Ss]pam [reply] [count]__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Nn]obody OR [Ee]verybody (LastSeen)__
≼┈┅┅━━━♡━━━┅┅┈≽
__cmd: set [cmd] {reply} | cmdlist | dcmd [cmd]__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Aa]utodel [NUM]__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Aa]ddserver [reply] -> USERNAME@IP;PASSWORD__
≼┈┅┅━━━♡━━━┅┅┈≽
__+[Cc]onnect (Connect to SHH addedserver)__
≼┈┅┅━━━♡━━━┅┅┈≽
__-exit() (Disconnect)__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Mm]ark [INCHAT] - mark anyway__
≼┈┅┅━━━♡━━━┅┅┈≽
__[Tt]oday__
≼┈┅┅━━━♡━━━┅┅┈≽
"""
@Client.on_message(Filters.regex("^[hH]elp$") & Filters.me, group=32)
def help(app : Client ,msg : Message):
    app.edit_message_text(
        msg.chat.id,
        msg.message_id,
        helptext)

    if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
