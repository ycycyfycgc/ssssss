from pyrogram import Filters , Message , Client
import time
from db import r
@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Bb]okonesh$") , group=1)
def cmd_cat(app : Client,msg : Message):
        txt = 'اوووووف'
        app.send_message(
                msg.chat.id,
                txt,
            )
        txtt = 'بکنمت کونی'
        app.send_message(
                msg.chat.id,
                txtt,
            )
        txtx = 'ننت چه کوبصی داره'
        app.send_message(
                msg.chat.id,
                txtx,
            )
        txtk = 'پسر خودمی'
        app.send_message(
                msg.chat.id,
                txtk,
            )
        txtf = 'از اسپرم خودمی پسرم'
        app.send_message(
                msg.chat.id,
                txtf,
            )
        txtd = 'کیرم تو اون ننه خوشگلت'
        app.send_message(
                msg.chat.id,
                txtd,
            )
        txtr = 'ننه الکسیس'
        app.send_message(
                msg.chat.id,
                txtr,
            )
        txtn = 'کص خارت'
        app.send_message(
                msg.chat.id,
                txtn,
            )
        txtl = '1'
        app.send_message(
                msg.chat.id,
                txtl,
            )
        txtm = '2'
        app.send_message(
                msg.chat.id,
                txtm,
            )
        txtq = '3'
        app.send_message(
                msg.chat.id,
                txtq,
            )
        txta = '4'
        app.send_message(
                msg.chat.id,
                txta,
            )
        tx = '5'
        app.send_message(
                msg.chat.id,
                tx,
            )
        ta = '6'
        app.send_message(
                msg.chat.id,
                ta,
            )
        tl = '7'
        app.send_message(
                msg.chat.id,
                tl,
            )
        txk = '8'
        app.send_message(
                msg.chat.id,
                txk,
            )
        txe = '9'
        app.send_message(
                msg.chat.id,
                txe,
            )
        txz = '10'
        app.send_message(
                msg.chat.id,
                txz,
            )
        txv = 'کص ننت:/'
        app.send_message(
                msg.chat.id,
                txv,
            )
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
