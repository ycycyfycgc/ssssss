from pyrogram import Filters , Message , Client , InlineKeyboardMarkup , ReplyKeyboardMarkup , ReplyKeyboardRemove , ForceReply
import time
from db import r

commands = [
"""
>>> `cube`
>>> `koobs`
>>> `bk`
>>> `update`
>>> `cat`
>>> `story`
>>> `laugh`
>>> `fuck`
>>> `pok`
>>> `gn`
>>> `gm`
>>> `joon`
>>> `oof`
>>> `number`
>>> `tbk`
>>> `khodkoshi`
>>> `love`
>>> `lover`
"""
]


reload = [
    "`start reloading`",
    "░░░░░░░░░░░░░░",
    "▓░░░░░░░░░░░░░",
    "▓▓░░░░░░░░░░░░",
    "▓▓▓░░░░░░░░░░░",
    "▓▓▓▓░░░░░░░░░░",
    "▓▓▓▓▓░░░░░░░░░",
    "▓▓▓▓▓▓░░░░░░░░",
    "▓▓▓▓▓▓▓░░░░░░░",
    "▓▓▓▓▓▓▓▓░░░░░░",
    "▓▓▓▓▓▓▓▓▓░░░░░",
    "▓▓▓▓▓▓▓▓▓▓░░░░",
    "▓▓▓▓▓▓▓▓▓▓▓░░░",
    "▓▓▓▓▓▓▓▓▓▓▓▓░░",
    "▓▓▓▓▓▓▓▓▓▓▓▓▓░",
    "▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
    "reloading.",
    "reloading..",
    "reloading...",
    "reloading.",
    "reloading..",
    "reloading...",
    "reloading.",
    "reloading..",
    "reloading...",
    "`reloaded! :)`",
]

load = [
    "`start Loading`",
    "Load.",
    "lOad..",
    "loAd...",
    "loaD.",
    "Load..",
    "lOad...",
    "loAd.",
    "loaD..",
    "Load...",
    "lOad.",
    "loAd..",
    "loaD...",
    "`Loading! :)`",
]

nasi = [
"""
**- - - - - - - - -**
> `Nkirshodan`
> `Nnoob`
> `Njagh`
> `Nkoslis`
> `Nbekiram`
**- - - - - - - - -**
"""
]

koobs = [
    "ک",
    "کو",
    "کوب",
    "کوبص",
    "کوبص ک",
    "کوبص کو",
    "کوبص کوب",
    "کوبص کوبص",
    "کوبص کوبص ک",
    "کوبص کوبص کو",
    "کوبص کوبص کوب",
    "کوبص کوبص کوبص",
]

cube = [
    """
🟥🟥🟥🟥
🟥🟥🟥🟥
🟥🟥🟥🟥
🟥🟥🟥🟥
    """,
    """
🟥🟥🟥🟥
🟥⬜️⬛️🟥
🟥⬛️⬜️🟥
🟥🟥🟥🟥
    """,
    """
🟥🟥🟥🟥
🟥⬛️⬜️🟥
🟥⬜️⬛️🟥
🟥🟥🟥🟥
    """,
    """
🟥🟥🟥⬛️
🟥⬜️⬛️🟥
🟥⬛️⬜️🟥
⬛️🟥🟥🟥
    """,
    """
🟥⬜️⬛️🟥
🟥⬛️⬜️🟥
🟥⬜️⬛️🟥
🟥⬛️⬜️🟥
    """,
    """
🟥⬛️⬜️🟥
🟥⬜️⬛️🟥
🟥⬛️⬜️🟥
🟥⬜️⬛️🟥
    """,
    """
⬜️⬛️⬜️⬛️
⬛️⬜️⬛️⬜️
⬜️⬛️⬜️⬛️
⬛️⬜️⬛️⬜️
    """,
    """
⬛️⬜️⬛️⬜️
⬜️⬛️⬜️⬛️
⬛️⬜️⬛️⬜️
⬜️⬛️⬜️⬛️
    """,
    """
🟥⬜️⬛️⬜️🟥
🟥⬛️⬜️⬛️🟥
🟥⬜️⬛️⬜️🟥
🟥⬛️⬜️⬛️🟥
🟥⬜️⬛️⬜️🟥
    """,
    """
🟥🟥🟥🟥🟥🟥🟥
🟥🟨🟨🟨🟨🟨🟥
🟥🟩🟩🟩🟩🟩🟥
🟥⬛️⬛️⬛️⬛️⬛️🟥
🟥🟦🟦🟦🟦🟦🟥
🟥⬜️⬜️⬜️⬜️⬜️🟥
🟥🟥🟥🟥🟥🟥🟥
    """,
    """
🟥🟥🟥🟥🟥🟥🟥
🟥💚💚💚💚💚🟥
🟥💙💙💙💙💙🟥
🟥❤️❤️❤️❤️❤️🟥
🟥💖💖💖💖💖🟥
🟥🤍🤍🤍🤍🤍🟥
🟥🟥🟥🟥🟥🟥🟥
    """,
    """
🟥🟥🟥🟥🟥🟥🟥
🟥▫️◼️▫️◼️▫️🟥
🟥◼️▫️◼️▫️◼️🟥
🟥◽️◼️◽️◼️◽️🟥
🟥◼️◽️◼️◽️◼️🟥
🟥◽️◼️◽️◼️◽️🟥
🟥🟥🟥🟥🟥🟥🟥
    """,
    """
🟥🟥🟥🟥🟥🟥🟥
🟥🔶🔷🔶🔷🔶🟥
🟥🔷🔶🔷🔶🔷🟥
🟥🔶🔷🔶🔷🔶🟥
🟥🔷🔶🔷🔶🔷🟥
🟥🔶🔷🔶🔷🔶🟥
🟥🟥🟥🟥🟥🟥🟥
    """,
    """
🟥🟥🟥🟥🟥🟥🟥
🟥♥️❤️♥️❤️♥️🟥
🟥❤️♥️❤️♥️❤️🟥
🟥♥️❤️♥️❤️♥️🟥
🟥❤️♥️❤️♥️❤️🟥
🟥♥️❤️♥️❤️♥️🟥
🟥🟥🟥🟥🟥🟥🟥
    """,
    """
💙💙💙💙
    """,
    """
__⇥ Finished:|__
    """,

]


goodrat = [
    "|> I'm Goodratmand <|"
]

gn = [
    "Good",
    "Night",
    "GoodNight🙂🌹",
]

gm = [
    "Good",
    "Morning",
    "GoodMorning🙂🌹",
]

kir = [
    """
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ◼️📜📜📜◼️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ◼️◼️◼️◼️◼️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
     ◼️📜📜📜📜📜◼️
          ◼️◼️◼️◼️◼️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
     ◼️📜📜◼️📜📜◼️
     ◼️📜📜📜📜📜◼️
          ◼️◼️◼️◼️◼️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
          ◼️📜◼️📜◼️
     ◼️📜📜◼️📜📜◼️
     ◼️📜📜📜📜📜◼️
          ◼️◼️◼️◼️◼️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
               ◼️◼️◼️
          ◼️📜◼️📜◼️
     ◼️📜📜◼️📜📜◼️
     ◼️📜📜📜📜📜◼️
          ◼️◼️◼️◼️◼️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
    """
.                 💦💦💦💦
                💦💦💦💦💦
               💦💦💦💦💦💦
               💦💦💦  💦💦💦
               💦💦💦        💦💦
               ◼️◼️◼️         💦💦
          ◼️📜◼️📜◼️   💦💦
     ◼️📜📜◼️📜📜◼️ 💦 
     ◼️📜📜📜📜📜◼️   💦
          ◼️◼️◼️◼️◼️        💦
          ◼️📜📜📜◼️        💦 
          ◼️📜📜📜◼️      💦
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️‌
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ⬛️📜📜📜⬛️
          ◼️📜📜📜◼️
          ◼️📜📜📜◼️
     ◼️📜📜📜📜📜◼️
◼️📜📜📜📜📜📜📜◼️
◼️📜📜📜◼️📜📜📜◼️
     ◼️◼️◼️     ◼️◼️◼️
    """,
]

bk = [
    """
😐😐😐
😐         😐
😐           😐
😐        😐
😐😐😐
😐         😐
😐           😐
😐           😐
😐        😐
😐😐😐
    """,
    """
🥀🥀🥀
🥀         🥀
🥀           🥀
🥀        🥀
🥀🥀🥀
🥀         🥀
🥀           🥀
🥀           🥀
🥀        🥀
🥀🥀🥀
    """,
    """
😐         😐
😐       😐
😐     😐
😐   😐
😐😐
😐   😐
😐      😐
😐        😐
😐          😐
😐            😐
    """,
    """
🥀         🥀
🥀       🥀
🥀     🥀
🥀   🥀
🥀🥀
🥀   🥀
🥀      🥀
🥀        🥀
🥀          🥀
🥀            🥀
    """,
    """
😐😐😐          😐         😐
😐         😐      😐       😐
😐           😐    😐     😐
😐        😐       😐   😐
😐😐😐          😐😐
😐         😐      😐   😐
😐           😐    😐      😐
😐           😐    😐        😐
😐        😐       😐          😐
😐😐😐          😐            😐
    """,
    """
🥀🥀🥀          🥀         🥀
🥀         🥀      🥀       🥀
🥀           🥀    🥀     🥀
🥀        🥀       🥀   🥀
🥀🥀🥀          🥀🥀
🥀         🥀      🥀   🥀
🥀           🥀    🥀      🥀
🥀           🥀    🥀        🥀
🥀        🥀       🥀          🥀
🥀🥀🥀          🥀            🥀
    """,
    """
__BK:)__
    """,
]

update = [
    "1%",
    "2%",
    "3%",
    "4%",
    "5%",
    "6%",
    "7%",
    "8%",
    "9%",
    "10% █",
    "11% █",
    "12% █",
    "13% █",
    "14% █",
    "15% █",
    "16% █",
    "17% █",
    "18% █",
    "19% █",
    "20% ██", 
    "21% ██",
    "22% ██",
    "23% ██",
    "24% ██",
    "25% ██",
    "26% ██",
    "27% ██",
    "28% ██",
    "29% ██",
    "30% ███",
    "31% ███",
    "32% ███",
    "33% ███",
    "34% ███",
    "35% ███",
    "36% ███",
    "37% ███",
    "38% ███",
    "39% ███",
    "40% ████",
    "41% ████",
    "42% ████",
    "43% ████",
    "44% ████",
    "45% ████",
    "46% ████",
    "47% ████",
    "48% ████",
    "49% ████",
    "50% █████",
    "51% █████",
    "52% █████",
    "53% █████",
    "54% █████",
    "55% █████",
    "56% █████",
    "57% █████",
    "58% █████",
    "59% █████",
    "60% ██████",
    "61% ██████",
    "62% ██████",
    "63% ██████",
    "64% ██████",
    "65% ██████",
    "66% ██████",
    "67% ██████",
    "68% ██████",
    "69% ██████",
    "70% ███████",
    "71% ███████",
    "72% ███████",
    "73% ███████",
    "74% ███████",
    "75% ███████",
    "76% ███████",
    "77% ███████",
    "78% ███████",
    "79% ███████",
    "80% ████████",
    "81% ████████",
    "82% ████████",
    "83% ████████",
    "84% ████████",
    "85% ████████",
    "86% ████████",
    "87% ████████",
    "88% ████████",
    "89% ████████",
    "90% █████████",
    "91% █████████",
    "92% █████████",
    "93% █████████",
    "94% █████████",
    "95% █████████",
    "96% █████████",
    "97% █████████",
    "98% █████████",
    "99% █████████",
    "100% ██████████",
    "__Updated!__",
    
]

story = [
    "💃🏻                                🚶🏻‍♂",
    "💃🏻                              🚶🏻‍♂",
    "💃🏻                            🚶🏻‍♂",
    "💃🏻                          🚶🏻‍♂",
    "💃🏻                        🚶🏻‍♂",
    "💃🏻                      🚶🏻‍♂",
    "💃🏻                    🚶🏻‍♂",
    "💃🏻                  🚶🏻‍♂",
    "💃🏻                🚶🏻‍♂",
    "💃🏻              🚶🏻‍♂",
    "💃🏻            🚶🏻‍♂",
    "💃🏻          🚶🏻‍♂",
    "💃🏻        🚶🏻‍♂",
    "💃🏻      🚶🏻‍♂",
    "💃🏻    🚶🏻‍♂",
    "💃🏻 |🚶🏻‍♂",
    "💃🏻    🚶🏻‍♂",
    "💃🏻      🚶🏻‍♂",
    "💃🏻        🚶🏻‍♂",
    "💃🏻          🚶🏻‍♂", 
    "💃🏻            🚶🏻‍♂",
    "💃🏻              🚶🏻‍♂",
    "💃🏻                🚶🏻‍♂",
    "💃🏻                  🚶🏻‍♂",
    "💃🏻                    🚶🏻‍♂",
    "💃🏻                      🚶🏻‍♂",
    "💃🏻                        🚶🏻‍♂",
    "💃🏻                            🚶🏻‍♂",
    "💃🏻                              🚶🏻‍♂",
    "💃🏻                                🚶🏻‍♂",
]

fuck = [
    "🖕",
    "🖕🏻",
    "🖕🏼",
    "🖕🏽",
    "🖕🏾",
    "🖕🏿",
    "🖕🏾",
    "🖕🏽",
    "🖕🏼",
    "🖕🏻",
    "🎭I Fuck You🎭",
]

laugh = [
    ":(",
    ":)",
    ":(",
    ":)",
    ":(",
    ":)",
    ":(",
    ":)",
    ":(",
    ":)",
    ":(",
    ":)",
    ":(",
    ":)",
    ":(",
    ":)",

]

poke = [
    ":|",
    "|:",
    ":|",
    "|:",
    ":|",
    "|:",
    ":|",
    "|:",
    ":|",
    "|:",
    ":|",
    "|:",
    ":|",
    "|:",
    ":|",
    "|:",
    ":|",

]

loveo = [
    "L",
    "O",
    "V",
    "E",
    "LOVE:)",
]

pok = [
    "I",
    "Love",
    "You!",
    "~ I love You!",
]

joon = [
    "Jooon",
    "Joooon",
    "Jooooon",
    "Joooooon",
    "Jooooooon",
    "Joooooooon",
    "Jooooooooon",
    "Joooooooooon",
    "Jooooooooooon",
    "Joooooooooooon",
    "Jooooooooooooon",
]

oof = [
    "ooof",
    "oooof",
    "ooooof",
    "oooooof",
    "ooooooof",
    "oooooooof",
    "ooooooooof",
    "oooooooooof",
    "ooooooooooof",
    "oooooooooooof",
    "ooooooooooooof",
]

number = [
    "`10`",
    "`9`",
    "`8`",
    "`7`",
    "`6`",
    "`5`",
    "`4`",
    "`3`",
    "`2`",
    "`1`",
    "__Sik:|__",
]

tbk = [
    "`B`",
    "`E`",
    "`K`",
    "`I`",
    "`R`",
    "`A`",
    "`M`",
    "`BK`",
]

creator = [
    "T.ME/AloneHeartless",
]

khodkoshi = [
    "🕳                      🚶🏻‍♂️",
    "🕳                     🚶🏻‍♂️",
    "🕳                    🚶🏻‍♂️",
    "🕳                   🚶🏻‍♂️",
    "🕳                  🚶🏻‍♂️",
    "🕳                 🚶🏻‍♂️",
    "🕳                🚶🏻‍♂️",
    "🕳               🚶🏻‍♂️",
    "🕳              🚶🏻‍♂️",
    "🕳             🚶🏻‍♂️",
    "🕳            🚶🏻‍♂️",
    "🕳           🚶🏻‍♂️",
    "🕳          🚶🏻‍♂️",
    "🕳         🚶🏻‍♂️",
    "🕳        🚶🏻‍♂️",
    "🕳       🚶🏻‍♂️",
    "🕳      🚶🏻‍♂️",
    "🕳     🚶🏻‍♂️",
    "🕳    🚶🏻‍♂️",
    "🕳   🚶🏻‍♂️",
    "🕳  🚶🏻‍♂️",
    "🕳 🚶🏻‍♂️",
    "🕳🚶🏻‍♂️",
    "__Oh Shit🙁__",
    "__Heartless Is Dead😢__",
]

love = [
    "❤️",
    "🧡",
    "💛",
    "💚",
    "💙",
    "💜",
    "🖤",
    "🤍",
    "💝",
]

lover = [
    "❤️🖤❤️🖤",
    "🖤❤️🖤❤️",
    "❤️🖤❤️🖤",
    "🖤❤️🖤❤️",
    "❤️🖤❤️🖤",
    "🖤❤️🖤❤️",
    "❤️🖤❤️🖤",
    "🖤❤️🖤❤️",
    "❤️🖤❤️🖤",
    "__My Text For You:__",
    "__I__",
    "__I L__",
    "__I Lo__",
    "__I Lov__",
    "__I Love__",
    "__I Love Y__",
    "__I Love Yo__",
    "__I Love You__",
    "❤️❤️ __I Love You__ ❤️❤️",
    "🖤🖤 __I Love You__ 🖤🖤",
    "💜💜 __I Love You__ 💜💜",
    "💚💚 __I Love You__ 💚💚",
    "💛💛 __I Love You__ 💛💛",
    "💙💙 __I Love You__ 💙💙",
    "__⇥ Finished:|__",
]

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Rr]eload$") , group=1)
def cmd_reload(app : Client,msg : Message):
    for i in reload:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Oo]of$") , group=1)
def cmd_reload(app : Client,msg : Message):
    for i in oof:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ll]oveo$") , group=1)
def cmd_loveo(app : Client,msg : Message):
    for i in loveo:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Gg]n$") , group=1)
def cmd_reload(app : Client,msg : Message):
    for i in gn:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Gg]oodrat$") , group=1)
def cmd_reload(app : Client,msg : Message):
    for i in goodrat:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ll]oad$"), group=2)
def cmd_load(app : Client, msg: Message):
 
    for i in load:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
    if r.get("autodel") == "on":
        time.sleep(float(r.get("autodeltime")))
        app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ll]ove$") , group=1)
def cmd_love(app : Client,msg : Message):
    for i in love:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Kk]hodkoshi$") , group=1)
def cmd_khodkoshi(app : Client,msg : Message):
    for i in khodkoshi:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Cc]reator$") , group=1)
def cmd_creator(app : Client,msg : Message):
    for i in creator:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Kk]ir$") , group=1)
def cmd_kir(app : Client,msg : Message):
    for i in kir:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)


@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Nn]umber$") , group=1)
def cmd_number(app : Client,msg : Message):
    for i in number:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Jj]oon$") , group=1)
def cmd_joon(app : Client,msg : Message):
    for i in joon:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Tt]bk$") , group=1)
def cmd_tbk(app : Client,msg : Message):
    for i in tbk:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ll]augh$") , group=1)
def cmd_laugh(app : Client,msg : Message):
    for i in laugh:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ss]tory$") , group=1)
def cmd_story(app : Client,msg : Message):
    for i in story:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ll]over$") , group=1)
def cmd_lover(app : Client,msg : Message):
    for i in lover:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ff]uck$") , group=1)
def cmd_fuck(app : Client,msg : Message):
    for i in fuck:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Pp]ok$") , group=1)
def cmd_pok(app : Client,msg : Message):
    for i in pok:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Cc]ube$") , group=1)
def cmd_cube(app : Client,msg : Message):
    for i in cube:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Bb]k$") , group=1)
def cmd_bk(app : Client,msg : Message):
    for i in bk:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Uu]pdate$") , group=1)
def cmd_update(app : Client,msg : Message):
    for i in update:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Kk]oobs$") , group=1)
def cmd_koobs(app : Client,msg : Message):
    for i in koobs:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Cc]at$") , group=1)
def cmd_cat(app : Client,msg : Message):
    for i in cat:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Gg]oodrat$") , group=1)
def cmd_goodrat(app : Client,msg : Message):
    for i in goodrat:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Cc]ommands$") , group=1)
def cmd_commands(app : Client,msg : Message):
    for i in commands:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Gg]m$") , group=1)
def cmd_gm(app : Client,msg : Message):
    for i in gm:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Gg]n$") , group=1)
def cmd_gn(app : Client,msg : Message):
    for i in gn:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ss]elf$") , group=1)
def cmd_cat(app : Client,msg : Message):
        txt = '__Joon:)__' 
        app.send_message(
                msg.chat.id,
                txt,
            )
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
