#app.send_photo("me", "photo.jpg", caption="Holidays!")
#app.send_photo("me", "photo.jpg", caption="Holidays!")
#https://uupload.ir/files/lrep_photo_2020-12-18_14-59-03.jpg
from pyrogram import Client , Message , Filters , InputMediaPhoto
from db import r
import time

@Client.on_message(Filters.regex("^[Hh]eartless$") & Filters.me, group=32)
def help(app : Client ,msg : Message):
    txt = "https://uupload.ir/files/lrep_photo_2020-12-18_14-59-03.jpg"
    app.send_photo(
        msg.chat.id,
        txt,)
    txf = "~ My Admin > @SirHeartless"
    app.send_message(
        msg.chat.id,
        txf,
        )
#@Client.on_message(Filters.regex("^[Hh]eartless$") & Filters.me, group=32)
#def h(app : Client ,msg : Message):
