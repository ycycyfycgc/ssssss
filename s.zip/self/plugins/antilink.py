from pyrogram import Client , Message , Filters
from db import r
import time


@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Cc]rgp$") , group=1)
def cmd_gp(app : Client,msg : Message):
    m = msg.text
    user_id = msg.reply_to_message.from_user.id
    app.create_group(msg.chat.id,msg.message_id,user_id)
    if r.get("autodel") == "on":
        time.sleep(float(r.get("autodeltime")))
        app.delete_messages(msg.chat.id,msg.message_id)
