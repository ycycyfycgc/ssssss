from pyrogram import Filters , Message , Client , InlineKeyboardMarkup , ReplyKeyboardMarkup , ReplyKeyboardRemove , ForceReply
import time
from db import r


@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Hh]ash > heartless$") , group=1)
def heartless(app : Client,msg : Message):
        txt = """
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
**> Info For** `heartless`
**> Help For Know Types:**
`(Hash-Type > Str > Hash)`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-1` > `heartless` > `9747d391962e2e7a2ed3bd7f1943daadb598403c`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-256` > `heartless` > `4a0987179ff6982ef731596e659efaafa86dd2400e0f7b0fff7345dc0b9cf514`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-512` > `heartless` > `ff19d4aec2b68fb1499620ce7712577be8e28c20bdf36b50c634d4b83bde25908e85cf5328237ceaf1bb54cd6a57288447723f3c7064475243685ea64d0d92ea`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`MD5` > `heartless` > `5fe6681b0ab28d011741c07c0fd4e0b1`
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
"""
        app.send_message(
                msg.chat.id,
                txt,
                )


@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Hh]ash > cipherx$") , group=2)
def hg(app : Client,msg : Message):
        txg = """
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
**> Info For** `cipherx`
**> Help For Know Types:**
`(Hash-Type > Str > Hash)`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-1` > `cipherx` > `08406a6e18bdf83010ddd1187251454d`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-256` > `cipherx` > `46ed87bc33c01880fe67cebdf34c1c7ea71c6413af7f7ea02121993dae4906d8`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-512` > `cipherx` > `d6826fcc4623b4f8a38673634f5e09fe3415c42e370789c421c09df2392de06c1c55fd6aa3f12fe1becdf314997391b41f75779219af8368a0f58c44f80f8ae0`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`MD5` > `cipherx` > `14ecf42fbbdae889b8789b9740ebd531`
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
"""
        app.send_message(
                msg.chat.id,
                txg,
                )

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Hh]ash > lorddark$") , group=2)
def hp(app : Client,msg : Message):
        txp = """
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
**> Info For** `lorddark`
**> Help For Know Types:**
`(Hash-Type > Str > Hash)`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-1` > `lorddark` > `bb117f43c54ea2e0c27aaa2331859a9ffb36185b`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-256` > `lorddark` > `fc026471f892533b288f7e9786df9c4dfc54399ec4ae25e9e8117097f6afe711`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-512` > `lorddark` > `9bdd2b768ddc27a38d5eb294f4862cc0edc96261060207d322b520dafe88a3a9c424ebb899a268355f5ae0917b12a6413cf7b9a1385fba715c3592ccb1981ad8`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`MD5` > `lorddark` > `6e9eea445c09a3123b05054dd469f5d5`
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
"""
        app.send_message(
                msg.chat.id,
                txp,
                )


@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Hh]ash > mmd$") , group=2)
def hl(app : Client,msg : Message):
        txk = """
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
**> Info For** `mmd`
**> Help For Know Types:**
`(Hash-Type > Str > Hash)`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-1` > `mmd` > `2bfd74adce8bb8d8c10364902a2ae19c`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-256` > `mmd` > `b5331ee630104dc68a399f10302bb19db63e8fcd2bc094aa531c4885f199939d`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-512` > `mmd` > `f44f7bc2b67771e97aa963318fe5e18a7d6d81059a192b76267b83103115260a28888ac67b9419fe20cd5d78f3409e1bca1e81fceaa44ce375ed9bca266ecb28`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`MD5` > `mmd` > `2bfd74adce8bb8d8c10364902a2ae19c`
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
"""
        app.send_message(
                msg.chat.id,
                txk,
                )

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Hh]ash > koobs$") , group=2)
def hl(app : Client,msg : Message):
        txd = """
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
**> Info For** `koobs`
**> Help For Know Types:**
`(Hash-Type > Str > Hash)`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-1` > `koobs` > `035edf6cbf221a47846a951c7d1790e99331d70d`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-256` > `koobs` > `a619432efe5b515c002c25c6d1c24976245f1993e6d991e6929d598114624095`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`SHA-512` > `koobs` > `36c0dc785645086549f70fbf3f768e9bf03e8cdaf256e9e14028bc63b83be51192a6b0099e4bb83e47e5ce85930ebe1249f803fdd88fa4ac927c2a34d415a3bb`
- - - - - - - - - - - - - - - - - - - - - - - - - -
`MD5` > `koobs` > `fa5bfa4af75b007c2d72566a26080705`
≼┈┅┅┅━━━♡━━━┅┅┅┈≽
"""
        app.send_message(
                msg.chat.id,
                txd,
                )
